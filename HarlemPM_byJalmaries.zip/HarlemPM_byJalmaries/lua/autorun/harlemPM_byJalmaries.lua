player_manager.AddValidModel( "harlemPM_byJalmaries",                 "models/jalmaries/harlem/harlemPM_byJalmaries.mdl" )
list.Set( "PlayerOptionsModel",  "harlemPM_byJalmaries",                "models/jalmaries/harlem/harlemPM_byJalmaries.mdl" )
